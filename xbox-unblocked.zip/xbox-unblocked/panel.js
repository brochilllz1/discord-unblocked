const frame = document.getElementById('snapchat-frame');
const overlay = document.getElementById('loading-overlay');
const reloadBtn = document.getElementById('reload-btn');

async function load() {
  overlay.classList.remove('hidden');
  await chrome.browsingData.remove(
    { origins: ['https://www.xbox.com'] },
    { serviceWorkers: true }
  );
  frame.src = 'https://www.xbox.com/en-US/play';
}

frame.addEventListener('load', () => {
  overlay.classList.add('hidden');
});

reloadBtn.addEventListener('click', load);

load();
