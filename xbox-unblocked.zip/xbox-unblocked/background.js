const ORIGIN = 'https://www.xbox.com';

async function removeSW(url) {
  return chrome.browsingData.remove(
    { origins: [new URL(url).origin] },
    { serviceWorkers: true }
  );
}

chrome.runtime.onInstalled.addListener(() => {
  chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1, 2],
    addRules: [
      {
        id: 1,
        condition: {
          initiatorDomains: [chrome.runtime.id],
          resourceTypes: ['sub_frame'],
        },
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            { header: 'X-Frame-Options', operation: 'remove' },
            { header: 'Frame-Options', operation: 'remove' },
            { header: 'Content-Security-Policy', operation: 'remove' },
            { header: 'Content-Security-Policy-Report-Only', operation: 'remove' },
            { header: 'Cross-Origin-Opener-Policy', operation: 'remove' },
            { header: 'Cross-Origin-Embedder-Policy', operation: 'remove' },
            { header: 'Cross-Origin-Resource-Policy', operation: 'remove' },
          ],
        },
      },
      {
        id: 2,
        condition: {
          resourceTypes: ['sub_frame', 'main_frame'],
        },
        action: {
          type: 'modifyHeaders',
          responseHeaders: [
            { header: 'X-Frame-Options', operation: 'remove' },
            { header: 'Frame-Options', operation: 'remove' },
            { header: 'Content-Security-Policy', operation: 'remove' },
            { header: 'Content-Security-Policy-Report-Only', operation: 'remove' },
          ],
        },
      },
    ],
  });
});

chrome.action.onClicked.addListener(async () => {
  await removeSW(ORIGIN);
});
