const frame = document.getElementById('gfn-frame');
const overlay = document.getElementById('loading-overlay');
const reloadBtn = document.getElementById('reload-btn');

async function load() {
  overlay.classList.remove('hidden');
  await chrome.browsingData.remove(
    { origins: ['https://play.geforcenow.com'] },
    { serviceWorkers: true }
  );
  frame.src = 'https://play.geforcenow.com';
}

frame.addEventListener('load', () => {
  overlay.classList.add('hidden');
});

reloadBtn.addEventListener('click', load);

load();
