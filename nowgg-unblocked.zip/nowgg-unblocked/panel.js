const frame = document.getElementById('nowgg-frame');
const overlay = document.getElementById('loading-overlay');
const reloadBtn = document.getElementById('reload-btn');

async function load() {
  overlay.classList.remove('hidden');
  await chrome.browsingData.remove(
    { origins: ['https://now.gg'] },
    { serviceWorkers: true }
  );
  frame.src = 'https://now.gg';
}

frame.addEventListener('load', () => {
  overlay.classList.add('hidden');
});

reloadBtn.addEventListener('click', load);

load();
