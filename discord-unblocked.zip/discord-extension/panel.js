const frame = document.getElementById('discord-frame');
const overlay = document.getElementById('loading-overlay');
const reloadBtn = document.getElementById('reload-btn');

frame.addEventListener('load', () => {
  overlay.classList.add('hidden');
});

reloadBtn.addEventListener('click', () => {
  overlay.classList.remove('hidden');
  frame.src = frame.src;
});
