const frame = document.getElementById('snapchat-frame');
const overlay = document.getElementById('loading-overlay');
const reloadBtn = document.getElementById('reload-btn');

async function load() {
  overlay.classList.remove('hidden');
  await chrome.browsingData.remove(
    { origins: ['https://www.snapchat.com/web'] },
    { serviceWorkers: true }
  );
  frame.src = 'https://www.snapchat.com/web';
}

frame.addEventListener('load', () => {
  overlay.classList.add('hidden');
});

reloadBtn.addEventListener('click', load);

load();
