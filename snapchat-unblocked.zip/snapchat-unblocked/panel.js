const frame = document.getElementById('snapchat-frame');
const overlay = document.getElementById('loading-overlay');
const reloadBtn = document.getElementById('reload-btn');

frame.addEventListener('load', () => {
  overlay.classList.add('hidden');
});

reloadBtn.addEventListener('click', () => {
  overlay.classList.remove('hidden');
  frame.src = frame.src;
});
